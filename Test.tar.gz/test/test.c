
/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014                                                       */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Zhangfang                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/25                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhangfang,2014/09/25
 *
 */

#include<stdlib.h>
#include<stdio.h>
#include"menu.h"

#define debug


int results[9] = {1,1,1,1,1,1,1,};
char * info[9] =
{
    "test report",
    "TC1 InitMenuData Fail!",
    "TC2  FindCmd Fail!",
	"TC3 AddCmdDataNode Fail!",
	"TC4 DelCmdLinkTableNode Fail!",
	"TC5 GetCmdLinkTableHead Fail!",
	"TC6 GetNextCmdLinkTableNode Fail!",
	"TC7 initiateCmd Fail!",
	"TC8 initiateCmd Fail!",
};

extern tCmdLinkTable * head;

int main()
{
	int i; 
	tCmdLinkTable *pCmdLinkTable;
	int k = InitMenuData(&pCmdLinkTable);
	if(k == 0)
	{
		debug("TC1 success!\n");
        results[1] = 0;
	}
	char cmd[10];
	printf("请输入一个命令\n");
	scanf("%s",cmd);
	tDataNode* p = FindCmd(head, cmd);
	if( p == NULL)
    {
        debug("TC2 success\n");
        results[2] = 0;
    }
	tDataNode *pCmdNode;
	pCmdNode= (tDataNode*)malloc(sizeof(tDataNode));
	pCmdNode->pNext = NULL;
	pCmdNode->cmd = "acmd";
	pCmdNode->desc = NULL;
	pCmdNode->handler = NULL;
	int l = AddCmdDataNode(pCmdLinkTable, pCmdNode);
	if(l == 0)
	{
		debug("TC3 success\n");
        results[3] = 0;
	}
	ShowAllCmd(pCmdLinkTable);
	int m = DelCmdLinkTableNode(pCmdLinkTable, pCmdNode);
	if(m == 0)
	{
		debug("TC4 success\n！");
        results[4] = 0;
	}
	ShowAllCmd(pCmdLinkTable);
	tDataNode *r = GetCmdLinkTableHead(pCmdLinkTable);
	if(r != NULL)
	{
		debug("TC5 success\n");
        results[5] = 0;
	}
	tDataNode *s = GetNextCmdLinkTableNode(pCmdLinkTable, pCmdNode);
	if(s == NULL)
	{
		debug("TC6 success\n");
        results[6] = 0;
	}
    /* test report */
    printf("test report\n");
	int hasErr = 0;
    for(i=1;i<=8;i++)
    {
        if(results[i] == 1)
        {
            printf("Testcase Number %d F - %s\n",i,info[i]);
			hasErr = 1;
    	}
	}
	if(!hasErr)
	printf("all success!\n");
}














