
/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014                                                       */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Zhangfang                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/25                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhangfang,2014/09/25
 *
 */


#ifndef _MENU_H_
#define _MENU_H_

#include <pthread.h>

#define SUCCESS 0
#define FAILURE (-1)


int Help();
int Quit();

/*
 * LinkTable Type
 */
typedef struct CmdLinkTable
{

    struct DataNode *pHead;
    struct DataNode *pTail;
    int		SumOfNode;
    pthread_mutex_t mutex;
}tCmdLinkTable;

/* 
 *data struct and its operations
 */
typedef struct DataNode
{
	struct DataNode * pNext;
    char*   cmd;
    char*   desc;
    int     (*handler)();	
} tDataNode;


/* 
 *find a cmd in the cmdlinklist and return the datanode pointer
 */
tDataNode * FindCmd(tCmdLinkTable * head, char * cmd);

/*
 *show all cmd in cmdlistlist
 */
int ShowAllCmd(tCmdLinkTable * head);

/*
 *initiate data
 */
int InitMenuData(tCmdLinkTable ** ppCmdLinkTable);
/*
 * Create a CmdLinkTable
 */
tCmdLinkTable * CreateCmdLinkTable();
/*
 * Add a DataNode to CmdLinkTable
 */
int AddCmdDataNode(tCmdLinkTable *pCmdLinkTable,tDataNode * pCmdNode);
/*
 * Delete a CmdDataNode from CmdLinkTable
 */
int DelCmdLinkTableNode(tCmdLinkTable *pCmdLinkTable,tDataNode * pCmdNode);
/*
 * Delete a CmdLinkTable
 */
int DeleteCmdLinkTable(tCmdLinkTable *pCmdLinkTable);

/*
 * get CmdLinkTableHead
 */
tDataNode * GetCmdLinkTableHead(tCmdLinkTable *pCmdLinkTable);
/*
 * get next CmdLinkTableNode
 */
tDataNode * GetNextCmdLinkTableNode(tCmdLinkTable *pCmdLinkTable,tDataNode * pNode);


#endif
