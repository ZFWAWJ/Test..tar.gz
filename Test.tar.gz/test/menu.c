
/**************************************************************************************************/
/* Copyright (C) mc2lab.com, SSE@USTC, 2014                                                       */
/*                                                                                                */
/*  FILE NAME             :  menu.c                                                               */
/*  PRINCIPAL AUTHOR      :  Zhangfang                                                            */
/*  SUBSYSTEM NAME        :  menu                                                                 */
/*  MODULE NAME           :  menu                                                                 */
/*  LANGUAGE              :  C                                                                    */
/*  TARGET ENVIRONMENT    :  ANY                                                                  */
/*  DATE OF FIRST RELEASE :  2014/09/25                                                           */
/*  DESCRIPTION           :  This is a menu program                                               */
/**************************************************************************************************/

/*
 * Revision log:
 *
 * Created by Zhangfang,2014/09/25
 *
 */


#include<stdio.h>
#include<stdlib.h>


#include"menu.h"
tCmdLinkTable * head = NULL;



/* find a cmd in the linklist and return the datanode pointer */
tDataNode * FindCmd(tCmdLinkTable * head, char * cmd)
{
    tDataNode * pCmdNode = (tDataNode*)GetCmdLinkTableHead(head);
    while(pCmdNode != NULL)
    {
        if(!strcmp(pCmdNode->cmd, cmd))
        {
            return  pCmdNode;  
        }
        pCmdNode = (tDataNode*)GetNextCmdLinkTableNode(head,(tDataNode *)pCmdNode);
    }
    return NULL;
}


int InitMenuData(tCmdLinkTable ** ppCmdLinktable)
{
    *ppCmdLinktable = CreateCmdLinkTable();
    tDataNode* pCmdNode = (tDataNode*)malloc(sizeof(tDataNode));
    pCmdNode->cmd = "help";
    pCmdNode->desc = "Menu List:";
    pCmdNode->handler = Help;
    AddCmdDataNode(*ppCmdLinktable,(tDataNode *)pCmdNode);
    pCmdNode = (tDataNode*)malloc(sizeof(tDataNode));
    pCmdNode->cmd = "version";
    pCmdNode->desc = "Menu Program V1.0";
    pCmdNode->handler = NULL; 
    AddCmdDataNode(*ppCmdLinktable,(tDataNode *)pCmdNode);
    pCmdNode = (tDataNode*)malloc(sizeof(tDataNode));
    pCmdNode->cmd = "quit";
    pCmdNode->desc = "Quit from Menu Program V1.0";
    pCmdNode->handler = Quit; 
    AddCmdDataNode(*ppCmdLinktable,(tDataNode *)pCmdNode);
 
    return 0; 
}

/* show all cmd in listlist */
int ShowAllCmd(tCmdLinkTable * head)
{
    tDataNode * pCmdNode = (tDataNode*)GetCmdLinkTableHead(head);
    while(pCmdNode != NULL)
    {
        printf("%s - %s\n", pCmdNode->cmd, pCmdNode->desc);
        pCmdNode = (tDataNode*)GetNextCmdLinkTableNode(head,(tDataNode *)pCmdNode);
    }
    return 0;
}
/*
 * Create a CmdLinkTable
 */
tCmdLinkTable * CreateCmdLinkTable()
{
    tCmdLinkTable * pCmdLinkTable = (tCmdLinkTable *)malloc(sizeof(tCmdLinkTable));
    if(pCmdLinkTable == NULL)
    {
        return NULL;
    }
    pCmdLinkTable->pHead = NULL;
    pCmdLinkTable->pTail = NULL;
    pCmdLinkTable->SumOfNode = 0;
    pthread_mutex_init(&(pCmdLinkTable->mutex), NULL);
    return pCmdLinkTable;
}

/*
 * Add a AddCmdDataNode to CmdLinkTable
 */
int AddCmdDataNode(tCmdLinkTable *pCmdLinkTable,tDataNode * pCmdNode)
{
    if(pCmdLinkTable == NULL || pCmdNode == NULL)
    {
        return FAILURE;
    }
    pCmdNode->pNext = NULL;
    pthread_mutex_lock(&(pCmdLinkTable->mutex));
    if(pCmdLinkTable->pHead == NULL)
    {
        pCmdLinkTable->pHead = pCmdNode;
    }
    if(pCmdLinkTable->pTail == NULL)
    {
        pCmdLinkTable->pTail = pCmdNode;
    }
    else
    {
        pCmdLinkTable->pTail->pNext = pCmdNode;
        pCmdLinkTable->pTail = pCmdNode;
    }
	pCmdLinkTable->SumOfNode += 1 ;
	pthread_mutex_unlock(&(pCmdLinkTable->mutex));
    return SUCCESS;		
}

/*
 * Delete a CmdDataNode from CmdLinkTable
 */
int DelCmdLinkTableNode(tCmdLinkTable *pCmdLinkTable,tDataNode * pCmdNode)
{
    if(pCmdLinkTable == NULL || pCmdNode == NULL)
    {
        return FAILURE;
    }
    pthread_mutex_lock(&(pCmdLinkTable->mutex));
    if(pCmdLinkTable->pHead == pCmdNode)
    {
        pCmdLinkTable->pHead = pCmdLinkTable->pHead->pNext;
        pCmdLinkTable->SumOfNode -= 1 ;
        if(pCmdLinkTable->SumOfNode == 0)
        {
            pCmdLinkTable->pTail = NULL;	
        }
        pthread_mutex_unlock(&(pCmdLinkTable->mutex));
        return SUCCESS;
    }
    tDataNode * pCmdTempNode = pCmdLinkTable->pHead;
    while(pCmdTempNode != NULL)
    {    
        if(pCmdTempNode->pNext == pCmdNode)
        {
            pCmdTempNode->pNext = pCmdTempNode->pNext->pNext;
            pCmdLinkTable->SumOfNode -= 1 ;
            if(pCmdLinkTable->SumOfNode == 0)
            {
                pCmdLinkTable->pTail = NULL;	
            }
            pthread_mutex_unlock(&(pCmdLinkTable->mutex));
            return SUCCESS;				    
        }
        pCmdTempNode = pCmdTempNode->pNext;
    }
    pthread_mutex_unlock(&(pCmdLinkTable->mutex));
    return FAILURE;		
}

/*
 * get CmdLinkTableHead
 */
tDataNode * GetCmdLinkTableHead(tCmdLinkTable *pCmdLinkTable)
{
    if(pCmdLinkTable == NULL)
    {
        return NULL;
    }    
    return pCmdLinkTable->pHead;
}

/*
 * get next CmdLinkTableNode
 */
tDataNode * GetNextCmdLinkTableNode(tCmdLinkTable *pCmdLinkTable,tDataNode * pCmdNode)
{
    if(pCmdLinkTable == NULL || pCmdNode == NULL)
    {
        return NULL;
    }
    tDataNode * pCmdTempNode = pCmdLinkTable->pHead;
    while(pCmdTempNode != NULL)
    {    
        if(pCmdTempNode == pCmdNode)
        {
            return pCmdTempNode->pNext;				    
        }
        pCmdTempNode = pCmdTempNode->pNext;
    }
    return NULL;
}




int Help()
{
    ShowAllCmd(head);
    return 0; 
}

int Quit()
{
    exit(0);
}

















